﻿namespace test04_IsFalse.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_IsOdd()
        {
            Assert.IsFalse(Odd_Tests.isOdd(6), "6 is not an odd number but the method returned true.");
        }
    }
}
