﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test04_IsFalse
{
    public class Odd_Tests
    {
        public static bool isOdd(int num)
        {
            return num % 2 != 0;
        }
    }
}
