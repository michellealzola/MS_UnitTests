﻿namespace test01_AreEqual.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_CalculateRectangleArea()
        {
            int result = Rectangle_Tests.CalculateRectangleArea(5, 4);
            Assert.AreEqual(20, result, "The area calculation is incorrect.");
        }
    }
}
