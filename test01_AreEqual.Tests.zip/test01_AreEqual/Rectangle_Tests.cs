﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test01_AreEqual
{
    public class Rectangle_Tests
    {
        public static int CalculateRectangleArea(int length, int width)
        {
            return length * width;
        }
    }
}
