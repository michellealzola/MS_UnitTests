﻿namespace test07_ThrowsException.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_DivideNums()
        {
            Assert.ThrowsException<DivideByZeroException>(() => ThrowsException_Tests.DivideNums(10, 0));
        }
    }
}
