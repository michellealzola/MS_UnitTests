﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test02_AreNotEqual
{
    public class Numbers_Tests
    {
        public static int AddNumbers(int a, int b)
        {
            return a + b;
        }
    }
}
