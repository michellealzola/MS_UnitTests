﻿namespace test02_AreNotEqual.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_AddNumbers()
        {
            int result = Numbers_Tests.AddNumbers(3, 2);
            Assert.AreNotEqual(6, result, "The addition result is unexpectedly equal to 6.");
        }
    }
}
