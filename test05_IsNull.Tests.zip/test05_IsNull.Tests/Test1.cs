﻿namespace test05_IsNull.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_ReturnNullIfEmplty()
        {
            Assert.IsNull(Null_Tests.ReturnNullIfEmplty(""), "Null is explected but returned with a value.");
        }
    }
}
