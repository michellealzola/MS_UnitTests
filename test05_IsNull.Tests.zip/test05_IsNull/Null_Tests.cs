﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test05_IsNull
{
    public class Null_Tests
    {
        public static string ReturnNullIfEmplty(string str)
        {
            return string.IsNullOrEmpty(str) ? null : str;
        }
    }
}
