﻿namespace test10_AreNotSame.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_CreateNewInstance_AreNotSame()
        {
            var instance1 = AreNotSame_Tests.CreateInstance();
            var instance2 = AreNotSame_Tests.CreateInstance();

            Assert.AreNotEqual(instance1, instance2, "The instances are unexpectedly the same.");
        }
    }
}
