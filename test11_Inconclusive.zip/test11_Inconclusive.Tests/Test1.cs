﻿namespace test11_Inconclusive.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_NotYetImplemented()
        {
            Assert.Inconclusive("The test is not yet implemented.");
        }
    }
}
