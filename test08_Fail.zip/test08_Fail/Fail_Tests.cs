﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test08_Fail
{
    public class Fail_Tests
    {
        public static int ProcessNumber(int number)
        {
            if (number < 0)
                return -1;
            return number;
        }
    }
}
