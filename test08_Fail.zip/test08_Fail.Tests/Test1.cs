﻿namespace test08_Fail.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_ProcessNumber()
        {
            if (Fail_Tests.ProcessNumber(-1) == -1)
                Assert.Fail("Unexpected conditon occurred.");
        }
    }
}
