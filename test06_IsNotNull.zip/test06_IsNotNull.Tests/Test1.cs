﻿namespace test06_IsNotNull.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_ReturnValueIfNotNull()
        {
            Assert.IsNotNull(NotNull_Tests.ReturnValueIfNotNull("hello"), "The method unexpectedly returned null.");
        }
    }
}
