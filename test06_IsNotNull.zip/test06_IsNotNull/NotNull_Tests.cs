﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test06_IsNotNull
{
    public class NotNull_Tests
    {
        public static string ReturnValueIfNotNull(string str)
        {
            return string.IsNullOrEmpty(str) ? null : str;
        }
    }
}
