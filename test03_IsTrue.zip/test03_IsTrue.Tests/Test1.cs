﻿namespace test03_IsTrue.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_IsEven()
        {
            Assert.IsTrue(Even_Tests.IsEven(8), "8 is an even number but the method returned false.");
        }
    }
}
