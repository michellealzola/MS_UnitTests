﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test03_IsTrue
{
    public class Even_Tests
    {
        public static bool IsEven(int num)
        {
            return num % 2 == 0;
        }
    }
}
