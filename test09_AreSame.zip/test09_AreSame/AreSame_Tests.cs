﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test09_AreSame
{
    
    public class AreSame_Tests
    {
        private static readonly object _instance = new object();

        public static object GetInstance()
        {
            return _instance;
        }
    }
}
