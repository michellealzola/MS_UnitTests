﻿

namespace test09_AreSame.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Test_GetInstance_AreSame()
        {
            var instance1 = AreSame_Tests.GetInstance();
            var instance2 = AreSame_Tests.GetInstance();

            Assert.AreSame(instance1, instance2, "The instance are not the same");
        }
    }
}
